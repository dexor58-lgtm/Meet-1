# NEXORA GAMING

مشروع مستقل جديد لواجهة Gaming Futuristic، معدّ للعمل على Cloudflare Pages مع Pages Functions وD1 وR2. الموقع المرجعي تمت مراجعته على مستوى بنية الصفحة الظاهرة فقط؛ الهوية والمحتوى والواجهة هنا جديدة.

## الموجود حالياً
- واجهة عربية متجاوبة بتصميم أخضر داكن، خلفية هندسية، رسم SVG تجريدي ليد تحكم، قائمة جانبية متحركة، نافذة دخول/إنشاء حساب، وحركات تحترم `prefers-reduced-motion`.
- API للتسجيل وتسجيل الدخول والخروج باستخدام PBKDF2 عبر Web Crypto، جلسات عشوائية محفوظة على D1، وكوكي HttpOnly/Secure/SameSite.
- API لعرض الألعاب المنشورة فقط، ومسارات إدارية لإنشاء/تعديل/حذف الألعاب محمية بدور `admin` من قاعدة البيانات.
- تحديث الاسم المعروض ورفع صورة شخصية إلى R2 بعد التحقق من النوع والحجم.
- D1 migration أولية وإعداد Wrangler.

## مهم قبل الاستخدام العام
هذا تسليم أساس مشروع يحتاج إعداد الخدمات والاختبارات الأمنية قبل الإنتاج. التسجيل لا يفعّل التحقق من البريد الإلكتروني حالياً؛ لا تستخدمه لموقع عام حساس قبل إضافة مسار تحقق بالبريد وحدود لمحاولات الدخول وحماية إضافية من الإساءة. صور R2 محفوظة، لكن endpoint عرض الصورة الحالية خاص بصاحب الحساب فقط. لا توجد بيانات ألعاب تجريبية.

## المتطلبات
- Node.js حديث وnpm
- حساب Cloudflare وصلاحية إنشاء Pages وD1 وR2
- Wrangler CLI (يتم تثبيته عبر npm)

## التشغيل المحلي
1. `npm install`
2. سجّل دخولك: `npx wrangler login`
3. أنشئ قاعدة البيانات: `npx wrangler d1 create nexora-gaming-db`
4. انسخ `database_id` الناتج إلى `wrangler.toml` بدلاً من `REPLACE_WITH_D1_DATABASE_ID`.
5. أنشئ حاوية الصور: `npx wrangler r2 bucket create nexora-gaming-media`
6. نفّذ الترحيل محلياً: `npx wrangler d1 migrations apply nexora-gaming-db --local`
7. شغّل: `npm run dev`

## تجهيز الإنتاج
1. طبّق الترحيلات على الإنتاج: `npx wrangler d1 migrations apply nexora-gaming-db --remote`
2. تأكد من أن D1 binding اسمه `DB` وR2 binding اسمه `MEDIA` كما في `wrangler.toml`.
3. انشر عبر `npm run deploy` أو اربط مستودع GitHub بمشروع Cloudflare Pages واختر مجلد الجذر `.` كـ Build output directory. لا يوجد bundler أو build step مطلوب.
4. اختبر التسجيل والدخول والملف الشخصي ورفع الصورة في بيئة Preview أولاً.

## منح صلاحية الأدمن
لا يتم منح الصلاحية اعتماداً على البريد أو المعرّف المقدم وحدهما. بعد إنشاء الحساب والتحقق من ملكية البريد والهوية خارجياً، استخرج `id` الداخلي للحساب من D1 وتحقق يدوياً من أنه الحساب المقصود، ثم نفّذ:

```sql
UPDATE users SET role = 'admin' WHERE id = 'INTERNAL_USER_ID_VERIFIED';
```

نفّذ هذا الأمر عبر `npx wrangler d1 execute nexora-gaming-db --remote --command "..."` بعد استبدال القيمة والتحقق منها. لا تستخدم المعرّف `113322570D` كمعرّف داخلي تلقائياً؛ التطبيق ينشئ UUID داخلياً منفصلاً.

## API مختصر
- `POST /api/auth/register` — `{ "email", "password", "username" }`
- `POST /api/auth/login` — `{ "email", "password" }`
- `POST /api/auth/logout`
- `GET /api/auth/me`
- `GET /api/profile`
- `PATCH /api/profile` — `{ "displayName" }`
- `POST /api/profile/avatar` — raw image body، `Content-Type: image/jpeg|image/png|image/webp`
- `GET /api/games`
- `GET /api/admin/games`, `POST /api/admin/games`, `PATCH /api/admin/games/:id`, `DELETE /api/admin/games/:id` — admin only

## ملاحظات معروفة يجب إكمالها قبل الإنتاج
- إضافة تحقق بريد إلكتروني حقيقي وتدفق استعادة كلمة المرور.
- إضافة rate limiting، حماية CSRF ملائمة للنشر، ومراجعة أمنية شاملة.
- تنفيذ واجهة رفع/قص/معاينة الصورة بشكل كامل؛ الواجهة الحالية ترفع الملف المختار فقط ولا تنفذ أدوات القص والتحريك المطلوبة بعد.
- تنفيذ رفع غلاف اللعبة من لوحة الأدمن؛ API الحالي يدعم بيانات اللعبة وروابطها لكنه لا يرفع أغلفة من واجهة الإدارة بعد.
- إضافة اختبارات آلية وتكاملية على Cloudflare Preview؛ لا يمكن تأكيد نجاح الربط أو النشر قبل إعداد حساب Cloudflare والخدمات الفعلية.
- رابط الصورة الشخصية مقيد حالياً بصاحب الحساب عبر الجلسة، ويحتاج تصميم رابط خاص أو مسار عرض مضبوط إذا أريد عرض صور الأعضاء للآخرين.

## المرجع
تمت مراجعة الصفحة المتاحة على `https://r-cymod.pages.dev/` لفهم نمط الواجهة العامة فقط. لم يتم تعديلها أو نسخ أقسامها أو هويتها أو كودها.
