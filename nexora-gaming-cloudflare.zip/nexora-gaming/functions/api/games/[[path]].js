import { json, fail } from '../_utils.js';
export async function onRequest({ request, env }) {
  if (request.method !== 'GET') return fail('طريقة الطلب غير مدعومة.',405);
  const rows=await env.DB.prepare("SELECT id,title,description,category,cover_key,game_url,created_at FROM games WHERE status='published' ORDER BY created_at DESC").all();
  return json({ games:(rows.results || []).map(g=>({id:g.id,title:g.title,description:g.description,category:g.category,coverUrl:g.cover_key ? `/media/${g.cover_key}` : null,url:g.game_url,createdAt:g.created_at})) });
}
