import { json, fail, requireUser } from '../_utils.js';
export async function onRequest({ request, env }) {
  const auth = await requireUser(request, env); if (auth.error) return auth.error;
  const user = auth.user; const url = new URL(request.url);
  if (request.method === 'GET' && url.pathname.endsWith('/profile')) return json({ profile: { id:user.id, username:user.username, displayName:user.display_name, avatarUrl:user.avatar_key ? `/api/profile/avatar/${user.id}` : null } });
  if (request.method === 'PATCH' && url.pathname.endsWith('/profile')) {
    let body; try { body=await request.json(); } catch { return fail('البيانات غير صالحة.'); }
    const displayName=String(body.displayName || '').trim();
    if (displayName.length < 2 || displayName.length > 40) return fail('الاسم المعروض يجب أن يكون بين حرفين و40 حرفاً.');
    await env.DB.prepare("UPDATE users SET display_name=?,updated_at=datetime('now') WHERE id=?").bind(displayName,user.id).run();
    return json({ ok:true, displayName });
  }
  if (request.method === 'POST' && url.pathname.endsWith('/avatar')) {
    const type=request.headers.get('content-type') || '';
    if (!type.startsWith('image/')) return fail('ارفع ملف صورة فقط.');
    const buffer=await request.arrayBuffer();
    if (!buffer.byteLength || buffer.byteLength > 5*1024*1024) return fail('حجم الصورة يجب ألا يتجاوز 5 ميغابايت.');
    const allowed={'image/jpeg':'jpg','image/png':'png','image/webp':'webp'};
    if (!allowed[type]) return fail('الأنواع المدعومة: JPG وPNG وWebP.');
    const key=`avatars/${user.id}/${crypto.randomUUID()}.${allowed[type]}`;
    await env.MEDIA.put(key, buffer, { httpMetadata:{ contentType:type, cacheControl:'public, max-age=86400' } });
    if (user.avatar_key) await env.MEDIA.delete(user.avatar_key);
    await env.DB.prepare("UPDATE users SET avatar_key=?,updated_at=datetime('now') WHERE id=?").bind(key,user.id).run();
    return json({ ok:true, avatarUrl:`/api/profile/avatar/${user.id}` });
  }
  const match=url.pathname.match(/\/profile\/avatar\/([^/]+)$/);
  if (request.method === 'GET' && match) {
    if (match[1] !== user.id) return fail('غير مسموح.',403);
    if (!user.avatar_key) return fail('لا توجد صورة شخصية.',404);
    const object=await env.MEDIA.get(user.avatar_key); if (!object) return fail('الصورة غير موجودة.',404);
    return new Response(object.body,{headers:{'content-type':object.httpMetadata?.contentType || 'application/octet-stream','cache-control':'private, max-age=300','x-content-type-options':'nosniff'}});
  }
  return fail('المسار غير موجود.',404);
}
