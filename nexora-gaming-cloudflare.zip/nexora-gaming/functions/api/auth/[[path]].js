import { json, fail, cookieHeader, sha256, passwordHash, verifyPassword, validEmail, currentUser } from '../_utils.js';
export async function onRequest({ request, env }) {
  const url = new URL(request.url);
  if (request.method === 'GET' && url.pathname.endsWith('/me')) {
    const user = await currentUser(request, env);
    return json({ user: user ? publicUser(user) : null });
  }
  if (request.method !== 'POST') return fail('طريقة الطلب غير مدعومة.', 405);
  let body; try { body = await request.json(); } catch { return fail('البيانات المرسلة غير صالحة.'); }
  if (url.pathname.endsWith('/register')) {
    const email = String(body.email || '').trim().toLowerCase();
    const password = String(body.password || '');
    const username = String(body.username || '').trim();
    if (!validEmail(email)) return fail('أدخل بريداً إلكترونياً صحيحاً.');
    if (password.length < 10 || password.length > 128) return fail('كلمة المرور يجب أن تكون بين 10 و128 حرفاً.');
    if (!/^[\p{L}\p{N}_-]{3,24}$/u.test(username)) return fail('اسم المستخدم يجب أن يكون 3–24 حرفاً أو رقماً أو _ أو -.');
    const exists = await env.DB.prepare('SELECT id FROM users WHERE email=? OR username=?').bind(email, username).first();
    if (exists) return fail('البريد الإلكتروني أو اسم المستخدم مستخدم بالفعل.', 409);
    const id = crypto.randomUUID();
    const hash = await passwordHash(password);
    await env.DB.prepare('INSERT INTO users (id,email,password_hash,username,display_name) VALUES (?,?,?,?,?)').bind(id,email,hash,username,username).run();
    return createSession(id, env);
  }
  if (url.pathname.endsWith('/login')) {
    const email = String(body.email || '').trim().toLowerCase();
    const password = String(body.password || '');
    const user = await env.DB.prepare('SELECT id,password_hash FROM users WHERE email=?').bind(email).first();
    if (!user || !(await verifyPassword(password, user.password_hash))) return fail('البريد الإلكتروني أو كلمة المرور غير صحيحة.', 401);
    return createSession(user.id, env);
  }
  if (url.pathname.endsWith('/logout')) {
    const cookie = request.headers.get('Cookie') || '';
    const match = cookie.match(/(?:^|;\s*)ng_session=([^;]+)/);
    if (match) { const token = decodeURIComponent(match[1]); await env.DB.prepare('DELETE FROM sessions WHERE token_hash=?').bind(await sha256(token)).run(); }
    return json({ ok: true }, 200, { 'set-cookie': cookieHeader('', 0) });
  }
  return fail('المسار غير موجود.', 404);
}
async function createSession(userId, env) {
  const token = [...crypto.getRandomValues(new Uint8Array(32))].map(b => b.toString(16).padStart(2,'0')).join('');
  const tokenHash = await sha256(token);
  await env.DB.prepare("INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,datetime('now','+14 days'))").bind(tokenHash,userId).run();
  const user = await env.DB.prepare('SELECT id,email,username,display_name,avatar_key,role,email_verified FROM users WHERE id=?').bind(userId).first();
  return json({ user: publicUser(user) }, 200, { 'set-cookie': cookieHeader(token) });
}
function publicUser(u) { return { id:u.id,email:u.email,username:u.username,displayName:u.display_name,avatarUrl:u.avatar_key ? `/api/profile/avatar/${encodeURIComponent(u.id)}` : null,role:u.role,emailVerified:!!u.email_verified }; }
