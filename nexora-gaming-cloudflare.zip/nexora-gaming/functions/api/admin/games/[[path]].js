import { json, fail, requireAdmin } from '../../_utils.js';
export async function onRequest({ request, env }) {
  const auth=await requireAdmin(request,env); if(auth.error) return auth.error;
  const url=new URL(request.url); const id=url.pathname.split('/').filter(Boolean).at(-1);
  if(request.method==='POST') {
    let b; try{b=await request.json()}catch{return fail('البيانات غير صالحة.')}
    const title=String(b.title||'').trim(), description=String(b.description||'').trim(), category=String(b.category||'Other').trim(), gameUrl=String(b.url||'').trim(), status=b.status==='published'?'published':'draft';
    try { const parsed=new URL(gameUrl); if(!['https:','http:'].includes(parsed.protocol)) throw new Error(); } catch { return fail('أدخل رابط لعبة صحيحاً يبدأ بـ http أو https.'); }
    if(title.length<2||title.length>100||description.length>2000||category.length>40) return fail('تحقق من الاسم والوصف والتصنيف.');
    const gameId=crypto.randomUUID();
    await env.DB.prepare("INSERT INTO games(id,title,description,category,game_url,status,created_by) VALUES(?,?,?,?,?,?,?)").bind(gameId,title,description,category,gameUrl,status,auth.user.id).run();
    return json({ok:true,id:gameId},201);
  }
  if(request.method==='PATCH' && id && id!=='games') {
    let b;try{b=await request.json()}catch{return fail('البيانات غير صالحة.')}
    const title=String(b.title||'').trim(),description=String(b.description||'').trim(),category=String(b.category||'Other').trim(),gameUrl=String(b.url||'').trim(),status=b.status==='published'?'published':'draft';
    try{const p=new URL(gameUrl);if(!['https:','http:'].includes(p.protocol))throw new Error()}catch{return fail('رابط اللعبة غير صالح.')}
    const result=await env.DB.prepare("UPDATE games SET title=?,description=?,category=?,game_url=?,status=?,updated_at=datetime('now') WHERE id=?").bind(title,description,category,gameUrl,status,id).run();
    return result.meta.changes ? json({ok:true}) : fail('اللعبة غير موجودة.',404);
  }
  if(request.method==='DELETE' && id && id!=='games') {
    const result=await env.DB.prepare('DELETE FROM games WHERE id=?').bind(id).run();
    return result.meta.changes ? json({ok:true}) : fail('اللعبة غير موجودة.',404);
  }
  if(request.method==='GET') { const rows=await env.DB.prepare('SELECT id,title,description,category,game_url,status,created_at FROM games ORDER BY created_at DESC').all(); return json({games:rows.results||[]}); }
  return fail('المسار غير موجود.',404);
}
