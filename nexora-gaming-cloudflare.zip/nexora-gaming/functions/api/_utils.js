const encoder = new TextEncoder();
export const json = (data, status = 200, headers = {}) => new Response(JSON.stringify(data), { status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', ...headers } });
export const fail = (message, status = 400) => json({ error: message }, status);
export function cookieValue(request, name) {
  const cookies = request.headers.get('Cookie') || '';
  const item = cookies.split(';').map(x => x.trim()).find(x => x.startsWith(name + '='));
  return item ? decodeURIComponent(item.slice(name.length + 1)) : null;
}
export function cookieHeader(value, maxAge = 60 * 60 * 24 * 14) {
  return `ng_session=${encodeURIComponent(value)}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${maxAge}`;
}
export async function sha256(value) {
  const bytes = await crypto.subtle.digest('SHA-256', encoder.encode(value));
  return [...new Uint8Array(bytes)].map(b => b.toString(16).padStart(2, '0')).join('');
}
export async function passwordHash(password, saltHex) {
  const salt = saltHex ? Uint8Array.from(saltHex.match(/.{2}/g).map(x => parseInt(x, 16))) : crypto.getRandomValues(new Uint8Array(16));
  const key = await crypto.subtle.importKey('raw', encoder.encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt, iterations: 310000, hash: 'SHA-256' }, key, 256);
  const hex = [...new Uint8Array(bits)].map(b => b.toString(16).padStart(2, '0')).join('');
  const saltString = [...salt].map(b => b.toString(16).padStart(2, '0')).join('');
  return `${saltString}:${hex}`;
}
export async function verifyPassword(password, stored) {
  const [salt, expected] = String(stored || '').split(':');
  if (!salt || !expected) return false;
  const result = await passwordHash(password, salt);
  return result.split(':')[1] === expected;
}
export async function currentUser(request, env) {
  const token = cookieValue(request, 'ng_session');
  if (!token) return null;
  const tokenHash = await sha256(token);
  const row = await env.DB.prepare(`SELECT u.id,u.email,u.username,u.display_name,u.avatar_key,u.role,u.email_verified FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at > datetime('now')`).bind(tokenHash).first();
  return row || null;
}
export async function requireUser(request, env) {
  const user = await currentUser(request, env);
  if (!user) return { error: fail('يلزم تسجيل الدخول أولاً.', 401) };
  return { user };
}
export async function requireAdmin(request, env) {
  const result = await requireUser(request, env);
  if (result.error) return result;
  if (result.user.role !== 'admin') return { error: fail('هذه العملية مخصصة للأدمن.', 403) };
  return result;
}
export function validEmail(email) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email); }
